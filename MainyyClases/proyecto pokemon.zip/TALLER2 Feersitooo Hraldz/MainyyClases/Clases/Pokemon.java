package Clases;

public class Pokemon {

	private String nombre;
	private String habitad;
	private double porcAparicion;
	private int vida;
	private int ataque;
	private int defensa;
	private int ataqueEspecial;
	private int defensaEspecial;
	private int velocidad;
	private String tipo;

	public Pokemon() {
	}

	public Pokemon(String nombre, String habitad, double porcAparicion, int vida, int ataque, int defensa,
			int ataqueEspecial, int defensaEspecial, int velocidad, String tipo) {
		super();
		this.nombre = nombre;
		this.habitad = habitad;
		this.porcAparicion = porcAparicion;
		this.vida = vida;
		this.ataque = ataque;
		this.defensa = defensa;
		this.ataqueEspecial = ataqueEspecial;
		this.defensaEspecial = defensaEspecial;
		this.velocidad = velocidad;
		this.tipo = tipo;
	}

	public String getNombre() {
		return nombre;
	}

	public String getHabitad() {
		return habitad;
	}

	public double getPorcAparicion() {
		return porcAparicion;
	}

	public int getVida() {
		return vida;
	}

	public int getAtaque() {
		return ataque;
	}

	public int getDefensa() {
		return defensa;
	}

	public int getAtaqueEspecial() {
		return ataqueEspecial;
	}

	public int getDefensaEspecial() {
		return defensaEspecial;
	}

	public int getVelocidad() {
		return velocidad;
	}

	public String getTipo() {
		return tipo;
	}

	@Override
	public String toString() {
		return "Pokemon [nombre=" + nombre + "]";
	}
	public int getsuma() {
		int suma= getDefensa()+getAtaque()+getAtaqueEspecial()+getDefensaEspecial()+getVida()+getVelocidad();
		return suma;
	}
	}

